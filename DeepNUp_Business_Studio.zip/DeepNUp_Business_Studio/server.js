import 'dotenv/config';
import express from 'express';
import Stripe from 'stripe';
import Database from 'better-sqlite3';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const base = process.env.BASE_URL || `http://localhost:${port}`;
const secret = process.env.SESSION_SECRET || '';
if (secret.length < 32) throw new Error('Set SESSION_SECRET to a random string with at least 32 characters.');
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const db = new Database(path.join(root,'studio.db'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,passhash TEXT NOT NULL,stripe_customer TEXT,subscription TEXT DEFAULT 'inactive',month TEXT DEFAULT '',uses INTEGER DEFAULT 0);CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires INTEGER NOT NULL);`);
app.set('trust proxy', 1);
app.use(helmet({contentSecurityPolicy:false}));
app.post('/api/stripe-webhook', express.raw({type:'application/json'}), async (req,res)=>{
  if(!stripe || !process.env.STRIPE_WEBHOOK_SECRET) return res.sendStatus(503);
  let event; try {event=stripe.webhooks.constructEvent(req.body,req.headers['stripe-signature'],process.env.STRIPE_WEBHOOK_SECRET);}catch{return res.sendStatus(400)}
  try {
    if(event.type==='checkout.session.completed') {
      const s=event.data.object;
      if(s.mode==='subscription' && s.client_reference_id) db.prepare('UPDATE users SET stripe_customer=?,subscription=? WHERE id=?').run(s.customer,'active',s.client_reference_id);
    }
    if(['customer.subscription.updated','customer.subscription.deleted'].includes(event.type)) {
      const s=event.data.object;
      const active=['active','trialing'].includes(s.status)?'active':'inactive';
      db.prepare('UPDATE users SET subscription=? WHERE stripe_customer=?').run(active,s.customer);
    }
    res.json({received:true});
  } catch(e){console.error(e);res.sendStatus(500)}
});
app.use(express.json({limit:'16kb'}));
app.use(cookieParser());
app.use('/api',rateLimit({windowMs:15*60*1000,limit:90,standardHeaders:'draft-7',legacyHeaders:false}));
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){return `${salt}:${crypto.scryptSync(password,salt,64).toString('hex')}`}
function verifyPassword(password,stored){const [salt,hex]=stored.split(':');return !!salt && !!hex && crypto.timingSafeEqual(Buffer.from(hashPassword(password,salt).split(':')[1],'hex'),Buffer.from(hex,'hex'))}
function user(req){const token=req.cookies.studio_session;if(!token)return null;const session=db.prepare('SELECT user_id FROM sessions WHERE token=? AND expires>?').get(crypto.createHash('sha256').update(token).digest('hex'),Date.now());return session?db.prepare('SELECT id,email,subscription,uses,month FROM users WHERE id=?').get(session.user_id):null}
function signIn(res,id){const token=crypto.randomBytes(32).toString('hex');db.prepare('INSERT INTO sessions VALUES (?,?,?)').run(crypto.createHash('sha256').update(token).digest('hex'),id,Date.now()+30*86400000);res.cookie('studio_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:30*86400000})}
app.post('/api/register',(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');if(!/^\S+@\S+\.\S+$/.test(email)||password.length<10||password.length>128)return res.status(400).json({error:'Enter a valid email and a password with at least 10 characters.'});try{const id=crypto.randomUUID();db.prepare('INSERT INTO users(id,email,passhash) VALUES(?,?,?)').run(id,email,hashPassword(password));signIn(res,id);res.json({ok:true})}catch{return res.status(409).json({error:'Email already registered.'})}});
app.post('/api/login',(req,res)=>{const row=db.prepare('SELECT * FROM users WHERE email=?').get(String(req.body.email||'').trim().toLowerCase());if(!row || !verifyPassword(String(req.body.password||''),row.passhash))return res.status(401).json({error:'Incorrect email or password.'});signIn(res,row.id);res.json({ok:true})});
app.post('/api/logout',(req,res)=>{const token=req.cookies.studio_session;if(token)db.prepare('DELETE FROM sessions WHERE token=?').run(crypto.createHash('sha256').update(token).digest('hex'));res.clearCookie('studio_session');res.json({ok:true})});
app.get('/api/me',(req,res)=>{const u=user(req);res.json({user:u?{email:u.email,subscription:u.subscription,uses:u.month===new Date().toISOString().slice(0,7)?u.uses:0}:null,configured:{ai:!!process.env.OPENAI_API_KEY,payments:!!stripe&&!!process.env.STRIPE_MONTHLY_PRICE_ID},shopifyUrl:process.env.SHOPIFY_PRODUCT_URL||''})});
app.post('/api/subscribe',async(req,res)=>{const u=user(req);if(!u)return res.status(401).json({error:'Log in first.'});if(!stripe||!process.env.STRIPE_MONTHLY_PRICE_ID)return res.status(503).json({error:'Subscription checkout is not configured yet.'});try{const row=db.prepare('SELECT stripe_customer FROM users WHERE id=?').get(u.id);const s=await stripe.checkout.sessions.create({mode:'subscription',line_items:[{price:process.env.STRIPE_MONTHLY_PRICE_ID,quantity:1}],client_reference_id:u.id,customer:row.stripe_customer||undefined,customer_email:row.stripe_customer?undefined:u.email,success_url:base+'/?checkout=success',cancel_url:base+'/?checkout=cancel'});res.json({url:s.url})}catch(e){console.error(e);res.status(502).json({error:'Payment checkout could not be started.'})}});
app.post('/api/portal',async(req,res)=>{const u=user(req);if(!u)return res.sendStatus(401);if(!stripe)return res.sendStatus(503);const row=db.prepare('SELECT stripe_customer FROM users WHERE id=?').get(u.id);if(!row?.stripe_customer)return res.status(400).json({error:'No Stripe subscription was found.'});try{const session=await stripe.billingPortal.sessions.create({customer:row.stripe_customer,return_url:base});res.json({url:session.url})}catch{res.status(502).json({error:'Billing portal is not configured yet.'})}});
const tasks={ideas:'Generate 10 specific, low-cost business ideas for this audience, with customers, estimated startup costs and a testable first step. Do not promise earnings.',product:'Draft a digital product outline, compelling product name, suggested price to test, deliverables, and clear sales description.',marketing:'Write 5 authentic social media captions, 3 short video scripts, and 2 email pitches for this business. Avoid deceptive guarantees.',courier:'Create a practical delivery-business customer outreach plan, contract prospect checklist, and realistic sample quote structure. State any legal or insurance requirements must be checked locally.'};
app.post('/api/generate',async(req,res)=>{const u=user(req);if(!u)return res.status(401).json({error:'Create an account or log in.'});if(u.subscription!=='active')return res.status(403).json({error:'An active subscription is required.'});if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'AI provider is not configured yet.'});const kind=String(req.body.kind||'');const prompt=String(req.body.prompt||'').trim();if(!tasks[kind]||prompt.length<8||prompt.length>2500)return res.status(400).json({error:'Choose a tool and describe your business in 8–2500 characters.'});const month=new Date().toISOString().slice(0,7);const newCount=u.month===month?u.uses:0;if(newCount>=50)return res.status(429).json({error:'Monthly limit reached (50 generations).'});try{const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',instructions:'You are a practical small-business coach. Be clear and concise. Never guarantee sales or profits. '+tasks[kind],input:prompt,max_output_tokens:1100})});const data=await response.json();if(!response.ok)throw new Error(data.error?.message||'Provider error');const output=(data.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\n').trim();if(!output)throw new Error('No text was returned.');db.prepare('UPDATE users SET month=?,uses=? WHERE id=?').run(month,newCount+1,u.id);res.json({text:output,remaining:49-newCount})}catch(e){console.error(e);res.status(502).json({error:'AI generation failed. Check server API credentials and model access.'})}});
app.get('/health',(req,res)=>res.json({ok:true}));
app.use(express.static(path.join(root,'public')));
app.get('*',(req,res)=>res.sendFile(path.join(root,'public','index.html')));
app.listen(port,()=>console.log(`DEEP'N'UP running on ${base}`));
