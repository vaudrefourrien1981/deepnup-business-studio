# DEEP'N'UP Business Studio — Starter MVP

This is a working **starter codebase**, not an already-live, income-producing business. It combines:
1. A storefront linking to a digital product sold in your existing Shopify store.
2. A business landing page and registration/login.
3. A paid monthly AI planning service with Stripe subscription checkout and 50 monthly AI generations per user.

## Launch checklist

1. Install Node.js 20 or 22. Unzip this folder. In a terminal run `npm install`.
2. Copy `.env.example` to `.env`. Set a long random `SESSION_SECRET` (32+ characters). Run `npm start`, then open `http://localhost:3000`.
3. Upload `products/Delivery_Business_Starter_Kit.zip` to your **Shopify** store via a suitable digital-delivery app. Publish a $19 product, connect automatic file delivery, and paste its **full product page URL** in `SHOPIFY_PRODUCT_URL`. You can choose another price.
4. In **Stripe**, create a recurring monthly product and price (e.g., $15/month), then enter your secret key in `STRIPE_SECRET_KEY` and Price ID in `STRIPE_MONTHLY_PRICE_ID`.
5. In Stripe Dashboard, create webhook endpoint `https://YOUR-DOMAIN/api/stripe-webhook` and subscribe to `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`; copy the signing secret into `STRIPE_WEBHOOK_SECRET`. Enable Stripe customer portal for cancellations. **Webhook delivery is necessary to activate subscriptions.**
6. Create an OpenAI API key at the OpenAI developer platform, and put it in server-side `OPENAI_API_KEY`. Verify `OPENAI_MODEL` is accessible in your API project. This app calls POST `/v1/responses` securely from the server.
7. Deploy to a Node.js host with **persistent disk** for `studio.db`, HTTPS, and Node version matching `package.json`. Set `BASE_URL` to your real HTTPS URL and `NODE_ENV=production`. Do not use an ephemeral filesystem: user accounts and subscription records are in a local SQLite file and will be lost on nonpersistent deployments.
8. Use Stripe **test mode** first to verify checkout, successful webhook activation, AI generation, cancellation, and login. Then configure live mode and test again.

## Limitations to address before a public launch

- This is an MVP, not a hardened production SaaS. Add email verification, password reset, account deletion, CSRF protections on authenticated POST endpoints, privacy policy and terms, abuse monitoring, backups, support contact, and automated tests before accepting real customers.
- The app uses local SQLite; for multiple app instances or scalable serverless deployments, migrate users and sessions to managed storage.
- Stripe subscription access is controlled via signed webhooks and reflected in user records; subscription events can arrive out of order. Add periodic synchronization with Stripe for production resilience.
- The quote calculator and starter documents are informational. Ensure content and branding are reviewed before selling; do not imply guaranteed profits or specific legal compliance.
- $19 and $15/month are sample price points, not earnings promises. Stripe transaction fees, OpenAI API usage, taxes, Shopify fees, marketing, refunds, and hosting reduce net income.
- The HTML file alone is a preview only. Sign-in, checkout, and AI require the running backend.

## Security

Never put API keys in frontend JS or public repositories. Only set secrets in server environment variables. HTTPS is required in production for session cookies.
